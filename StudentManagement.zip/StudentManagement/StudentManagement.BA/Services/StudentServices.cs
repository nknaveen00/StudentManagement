﻿using StudentManagement.BA.Services.Interface;
using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Repository.Interface;
using System;

namespace StudentManagement.BA.Services
{
    public class StudentServices : IStudentServices
    {
        private readonly IStudentRepository userRepository;

        public StudentServices(IStudentRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        public async Task<Student> AddNewStudent(Student user)
        {
            return await userRepository.AddNewStudent(user);
        }

        public async Task<Student> DeleteStudent(Guid id)
        {
            return await userRepository.DeleteStudent(id);  
        }

        public async Task<Student> GetStudentDetail(Guid id)
        {
            return await userRepository.GetStudentDetail(id);
        }

        //public async Task<Student> UpdateStudent(Student user)
        //{
        //    return await userRepository.UpdateStudent(user);
        //}
    }
}
