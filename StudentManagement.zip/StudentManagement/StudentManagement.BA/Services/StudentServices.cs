﻿using StudentManagement.BA.Services.Interface;
using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Entity.Interface;
using StudentManagement.DAL.Repository.Interface;

namespace StudentManagement.BA.Services
{
    public class StudentServices : IStudentServices
    {
        private readonly IStudentRepository _student;

        public StudentServices(IStudentRepository userRepository)
        {
            this._student = userRepository;
        }

        public Guid CreateStudent(IStudent student)
        {
            var newStudent = new Student(student.FirstName, student.LastName, student.Email, student.Password);
            return _student.CreateStudent(newStudent);
        }

        public void DeleteStudent(Guid id)
        {
            _student.DeleteStudent(id);
        }

        public Student GetStudentById(Guid id)
        {
            return _student.GetStudentById(id);
        }

        public Guid UpdateStudent(IStudentUpdate student)
        {
            var newStudent=new Student(student.Id, student.FirstName, student.LastName, student.Email, student.Password);
            return _student.UpdateStudent(newStudent);
        }
    }
}
