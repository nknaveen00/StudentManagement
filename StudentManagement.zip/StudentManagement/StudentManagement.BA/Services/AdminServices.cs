﻿using StudentManagement.BA.Services.Interface;
using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Entity.Interface;
using StudentManagement.DAL.Repository.Interface;
using System;

namespace StudentManagement.BA.Services
{
    public class AdminServices : IAdminServices
    {
        private readonly IAdminRepository adminRepository;

        public AdminServices(IAdminRepository adminRepository)
        {
            this.adminRepository = adminRepository;
        }

        public async Task<Guid> AddNewAdmin(IAdmin admin)
        {
            var createAdmin = new Admin(admin.FirstName, admin.LastName, admin.Email, admin.Password);
            return  await adminRepository.AddNewAdmin(createAdmin);
        }

        public async Task<Admin> DeleteAdmin(Guid id)
        {
            return await adminRepository.DeleteAdmin(id);
        }

        public async Task<Admin> GetAdmin(Guid id)
        {
            return await adminRepository.GetAdmin(id);
        }

        public async Task<Admin> GetAdminDetails(Guid id)
        {
            return await adminRepository.GetAdminDetail(id);
        }

        public Task<Guid> UpdateAdmin(IAdminUpdate admin)
        {
            
        }
    }
}
