﻿using StudentManagement.BA.Services.Interface;
using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Entity.Interface;
using StudentManagement.DAL.Repository.Interface;

namespace StudentManagement.BA.Services
{
    public class AdminServices : IAdminServices
    {
        private readonly IAdminRepository adminRepository;

        public AdminServices(IAdminRepository adminRepository)
        {
            this.adminRepository = adminRepository;
        }

        public Admin GetAdminById(Guid id)
        {
            return adminRepository.GetAdminById(id);
        }

        public Guid CreateAdmin(IAdmin admin)
        {
            var createAdmin = new Admin(admin.FirstName, admin.LastName, admin.Email, admin.Password);
            return adminRepository.CreateAdmin(createAdmin);
        }

        public void DeleteAdmin(Guid id)
        {
            adminRepository.DeleteAdmin(id);
        }

        public Guid UpdateAdmin(IAdminUpdate admin)
        {
            var newAdmin=new Admin(admin.Id, admin.FirstName, admin.LastName, admin.Email, admin.Password);
            return adminRepository.UpdateAdmin(newAdmin);
        }
    }
}
