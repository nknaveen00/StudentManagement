﻿using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Entity.Interface;

namespace StudentManagement.BA.Services.Interface
{
    public interface IAdminServices
    {
        Guid CreateAdmin(IAdmin admin);
        Admin GetAdminById(Guid id);
        void DeleteAdmin(Guid id);
        Guid UpdateAdmin(IAdminUpdate admin);
    }
}
