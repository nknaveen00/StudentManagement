﻿using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Entity.Interface;
using System;

namespace StudentManagement.BA.Services.Interface
{
    public interface IAdminServices
    {
        public Task<Guid> AddNewAdmin(IAdmin admin);
        public Task<Guid> UpdateAdmin(IAdminUpdate admin);
        public Task<Admin> GetAdminDetails(Guid id);
        public Task<Admin> GetAdmin(Guid id);
        public Task<Admin> DeleteAdmin(Guid id);
    }
}
