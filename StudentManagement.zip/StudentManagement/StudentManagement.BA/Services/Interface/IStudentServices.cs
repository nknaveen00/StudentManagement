﻿using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Entity.Interface;

namespace StudentManagement.BA.Services.Interface
{
    public interface IStudentServices
    {
        void CreateStudent(IStudent student);
        Student GetStudentById(Guid id);
        void DeleteStudent(Guid id);
        Guid UpdateStudent(IStudentUpdate student);
    }
}
