﻿using StudentManagement.DAL.Entity.Interface;

namespace StudentManagement.Model
{
    public class UpdateAdminModel : IAdminUpdate
    {
        public Guid Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }

}
