﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using StudentManagement.BA.Services.Interface;
using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Entity.Interface;
using StudentManagement.Model;

namespace StudentManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : Controller
    {
        private readonly IAdminServices adminServices;
        private readonly IMapper mapper;

        public AdminController(IAdminServices adminServices , IMapper mapper)
        {
            this.adminServices = adminServices;
            this.mapper = mapper;
        }

        [HttpGet("GetAdminDetail")]
        public async Task<ActionResult<GetAdminStudentDetail>> GetAdminDetail(Guid id)
        {
            var admin = await adminServices.GetAdminDetails(id);
            if (admin == null)
                return NotFound();
            var adminDto=mapper.Map<GetAdminStudentDetail>(admin);
            if (adminDto == null)
                return NotFound();

            return Ok(adminDto);
        }


        [HttpGet]
        public async Task<ActionResult<GetAdminStudentLog>> GetAdmin(Guid id)
        {
            var admin= await adminServices.GetAdmin(id);
            if (admin == null)
                return NotFound();
            var adminDto = mapper.Map<GetAdminStudentLog>(admin);
            return Ok(adminDto);
        }


        [HttpPost]
        public async Task<IActionResult> CreateAdmin(CreateAdminModel createAdminModel)
        {
            var response = await adminServices.AddNewAdmin(createAdminModel);
            return Ok(response);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateAdmin(UpdateAdminModel updateAdmin)
        {
            var response = await adminServices.AddNewAdmin(createAdminModel);
            return Ok(response);
        }

        [HttpDelete]
        public async Task<ActionResult<Admin>> DeleteAdmin(Guid id)
        {
            var admin = await adminServices.DeleteAdmin(id);
            if (admin == null)
                return NotFound();
            
            var adminDto =mapper.Map<Admin>(admin);
            if (adminDto == null)
                return NotFound();
            return Ok(adminDto);
        }
    }
}
