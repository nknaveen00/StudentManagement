﻿using Microsoft.AspNetCore.Mvc;
using StudentManagement.BA.Services.Interface;
using StudentManagement.DAL.Entity;
using StudentManagement.Model;
using Swashbuckle.AspNetCore.Annotations;

namespace StudentManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : Controller
    {
        private readonly IAdminServices adminServices;

        public AdminController(IAdminServices adminServices)
        {
            this.adminServices = adminServices;
        }

        [HttpGet("{id:guid}")]
        [SwaggerResponse(200,"Admin Details")]
        [SwaggerOperation(
            Summary ="Getting Details of Admin",
            Description ="Getting Details of Admin",
            OperationId = "GetAdminById")]
        public ActionResult<Admin> GetAdminById(Guid id)
        {
            var admin = adminServices.GetAdminById(id);
            var newAdmin = new GetAdminStudentDetail(admin.Id, admin.FirstName, admin.LastName, admin.Email, admin.Password);
            return Ok(newAdmin);
        }

        [HttpPost]
        [SwaggerResponse(200, "Created New Admin")]
        [SwaggerOperation(
            Summary = "Creating a Admin",
            Description = "Creating a Admin",
            OperationId = "CreateAdmin")]
        public ActionResult<Guid> CreateAdmin(CreateAdminModel createAdminModel)
        {
            var id = adminServices.CreateAdmin(createAdminModel);
            return Ok(id);
        }

        [HttpDelete("{id:guid}")]
        [SwaggerResponse(200, "Admin was Deleted")]
        [SwaggerOperation(
            Summary = "Deleting a Admin",
            Description = "Deleting a Admin",
            OperationId = "DeleteAdmin")]
        public ActionResult DeleteAdmin(Guid id)
        {
            adminServices.DeleteAdmin(id);
            return Ok();
        }

        [HttpPut]
        [SwaggerResponse(200, "Updated Admin Details")]
        [SwaggerOperation(
            Summary = "Updating a Admin",
            Description = "Updating a Admin",
            OperationId = "UpdateAdmin")]
        public ActionResult<Guid> UpdateAdmin(UpdateAdminModel updateAdmin)
        {
            var adminId=adminServices.UpdateAdmin(updateAdmin);
            return Ok(adminId);
        }
    }
}