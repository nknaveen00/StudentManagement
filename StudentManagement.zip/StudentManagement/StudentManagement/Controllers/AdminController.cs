﻿using Microsoft.AspNetCore.Mvc;
using StudentManagement.BA.Services.Interface;
using StudentManagement.DAL.Entity;
using StudentManagement.Model;

namespace StudentManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : Controller
    {
        private readonly IAdminServices adminServices;

        public AdminController(IAdminServices adminServices)
        {
            this.adminServices = adminServices;
        }

        [HttpGet("{id:guid}")]
        public ActionResult<Admin> GetAdminById(Guid id)
        {
            var admin = adminServices.GetAdminById(id);
            var newAdmin = new GetAdminStudentDetail(admin.Id, admin.FirstName, admin.LastName, admin.Email, admin.Password);
            return Ok(newAdmin);
        }

        [HttpPost("{createAdminModel}")]
        public ActionResult CreateAdmin(CreateAdminModel createAdminModel)
        {
            adminServices.CreateAdmin(createAdminModel);
            return Ok();
        }

        [HttpDelete("{id:guid}")]
        public ActionResult DeleteAdmin(Guid id)
        {
            adminServices.DeleteAdmin(id);
            return Ok();
        }

        [HttpPut("{updateAdmin}")]
        public ActionResult<Guid> UpdateAdmin(UpdateAdminModel updateAdmin)
        {
            var adminId=adminServices.UpdateAdmin(updateAdmin);
            return Ok(adminId);
        }
        
    }
}



























/* [HttpGet("GetAdminDetail")]
        public async Task<ActionResult<GetAdminStudentDetail>> GetAdminDetail(Guid id)
        {
            var admin = await adminServices.GetAdminDetails(id);
            if (admin == null)
                return NotFound();
            var adminDto=mapper.Map<GetAdminStudentDetail>(admin);
            if (adminDto == null)
                return NotFound();

            return Ok(adminDto);
        }


        [HttpGet]
        public async Task<ActionResult<GetAdminStudentLog>> GetAdmin(Guid id)
        {
            var admin= await adminServices.GetAdmin(id);
            if (admin == null)
                return NotFound();
            var adminDto = mapper.Map<GetAdminStudentLog>(admin);
            return Ok(adminDto);
        }


        [HttpPost]
        public async Task<IActionResult> CreateAdmin(CreateAdminModel createAdminModel)
        {
            var response = await adminServices.AddNewAdmin(createAdminModel);
            return Ok(response);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateAdmin(UpdateAdminModel updateAdmin)
        {
            var response = await adminServices.AddNewAdmin(createAdminModel);
            return Ok(response);
        }

        [HttpDelete]
        public async Task<ActionResult<Admin>> DeleteAdmin(Guid id)
        {
            var admin = await adminServices.DeleteAdmin(id);
            if (admin == null)
                return NotFound();
            
            var adminDto =mapper.Map<Admin>(admin);
            if (adminDto == null)
                return NotFound();
            return Ok(adminDto);
        }*/