﻿using Microsoft.AspNetCore.Mvc;
using StudentManagement.BA.Services.Interface;
using StudentManagement.DAL.Entity;
using StudentManagement.Model;
using Swashbuckle.AspNetCore.Annotations;

namespace StudentManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StudentController : Controller
    {
        private readonly IStudentServices studentService;

        public StudentController(IStudentServices userServices)
        {
            this.studentService = userServices;
        }

        [HttpGet("{id:guid}")]
        [SwaggerResponse(200,"Student Details")]
        [SwaggerOperation(
            Summary ="Getting Student Details",
            Description = "Getting Student Details",
            OperationId = "GetStudentById")]
        public ActionResult<Student> GetStudentById(Guid id)
        {
            var student = studentService.GetStudentById(id);
            var newStudent = new GetAdminStudentDetail(student.Id, student.FirstName, student.LastName, student.Email, student.Password);
            return Ok(newStudent);
        }

        [HttpPost]
        [SwaggerResponse(200,"Created a Student")]
        [SwaggerOperation(
            Summary="Adding a Student",
            Description ="Adding a Student",
            OperationId = "CreateStudent")]
        public ActionResult<Guid> CreateStudent(CreateStudentModel createStudent)
        {
            var id = studentService.CreateStudent(createStudent);
            return Ok(id);
        }

        [HttpDelete("{id}")]
        [SwaggerResponse(200,"Deleted a Student")]
        [SwaggerOperation(
            Summary ="Deleting a Student",
            Description ="Deleting a Student",
            OperationId = "DeleteStudent")]
        public ActionResult DeleteStudent(Guid id)
        {
            studentService.DeleteStudent(id);
            return Ok();
        }

        [HttpPut]
        [SwaggerResponse(200,"Updated Student Details")]
        [SwaggerOperation(
            Summary ="Updating Student Details",
            Description = "Updating Student Details",
            OperationId = "UpdateStudent")]
        public ActionResult<Guid> UpdateStudent(UpdateStudentModel update)
        {
            var adminId = studentService.UpdateStudent(update);
            return Ok(adminId);
        }


    }
}






























/*




[HttpGet]
public async Task<ActionResult<GetAdminStudentDetail>> GetStudentDetail(Guid id)
{
    var response = await userServices.GetStudentDetail(id);
    var studentDto = mapper.Map<GetAdminStudentDetail>(response);
    if (studentDto == null)
        return NotFound();

    return Ok(studentDto);
}

[HttpPost]
public async Task<ActionResult<AddAdminStudent>> AddNewStudent(AddAdminStudent studentDto)
{
    var student = new Student()
    {
        FirstName = studentDto.FirstName,
        LastName = studentDto.LastName,
        Email = studentDto.Email,
        Password = studentDto.Password
    };
    var response = await userServices.AddNewStudent(student);
    studentDto = mapper.Map<AddAdminStudent>(response);
    if (studentDto == null)
        return NotFound();
    return Ok(studentDto);
}

[HttpDelete]
public async Task<ActionResult<AddAdminStudent>> DeleteStudent(Guid id)
{
    var response = await userServices.DeleteStudent(id);
    if (response == null)
        return NotFound();
    var studentDto = mapper.Map<AddAdminStudent>(response);
    return Ok(studentDto);
}

//[HttpPut]
//public async Task<ActionResult<UpdateStudent>> UpdateStudent(Guid id)
//{
//    var response = await userServices.UpdateStudent(id);
//    if (response == null)
//        return NotFound();
//    studentDto=mapper.Map<UpdateStudent>(response); 
//    return Ok(studentDto);
//}
*/