﻿using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Repository.Interface;
using System;

namespace StudentManagement.DAL.Repository
{
    public class StudentRepository : IStudentRepository
    {
        private readonly StudentDbContext studentDb;

        public StudentRepository(StudentDbContext studentDb)
        {
            this.studentDb = studentDb;
        }

        public async Task<Student> AddNewStudent(Student user)
        {
            await studentDb.Student.AddAsync(user);
            studentDb.SaveChanges();
            return studentDb.Student.FirstOrDefault(x => x.Id == user.Id);
        }

        public async Task<Student> DeleteStudent(Guid id)
        {
            var data = studentDb.Student.FirstOrDefault(x => x.Id == id);
            studentDb.Student.Remove(data);
            await studentDb.SaveChangesAsync();
            return studentDb.Student.FirstOrDefault(x => x.Id == id); ;
        }

        public async Task<Student> GetStudentDetail(Guid id)
        {
           return studentDb.Student.FirstOrDefault(x => x.Id == id);
        }

        //public async Task<Student> UpdateStudent(Student user)
        //{
        //    var data = studentDb.Student.FirstOrDefault(x => x.Id == user.Id);
        //    studentDb.Student.Remove(data);
        //    await studentDb.Student.AddAsync(user);
        //    await studentDb.SaveChangesAsync();
        //    return studentDb.Student.FirstOrDefault(x => x.Id == user.Id);
        //}
    }
}
