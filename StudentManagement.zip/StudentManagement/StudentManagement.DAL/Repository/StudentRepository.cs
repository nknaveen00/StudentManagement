﻿using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Repository.Interface;

namespace StudentManagement.DAL.Repository
{
    public class StudentRepository : IStudentRepository
    {
        private readonly StudentDbContext studentDb;

        public StudentRepository(StudentDbContext studentDb)
        {
            this.studentDb = studentDb;
        }

        public Guid CreateStudent(Student student)
        {
            studentDb.Student.Add(student);
            studentDb.SaveChanges();
            return student.Id;
        }

        public void DeleteStudent(Guid id)
        {
            var student=GetStudentById(id);
            studentDb.Student.Remove(student);
            studentDb.SaveChanges();
        }

        public Student GetStudentById(Guid id)
        {
            return studentDb.Student.Single(x=>x.Id == id);
        }

        public Guid UpdateStudent(Student student)
        {
            var existStudent = GetStudentById(student.Id);
            existStudent.FirstName= student.FirstName;
            existStudent.LastName=student.LastName;
            existStudent.Email= student.Email;
            existStudent.Password= student.Password;
            studentDb.SaveChanges();
            return existStudent.Id;
        }
    }
}
