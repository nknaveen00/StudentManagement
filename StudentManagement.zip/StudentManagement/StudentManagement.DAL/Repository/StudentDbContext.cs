﻿using Microsoft.EntityFrameworkCore;
using StudentManagement.DAL.Entity;

namespace StudentManagement.DAL.Repository
{
    public class StudentDbContext : DbContext
    {
        public StudentDbContext(DbContextOptions<StudentDbContext> options) : base(options)
        {

        }

        public DbSet<Admin> Admin { get; set; }
        public DbSet<Student> Student { get; set; }
    }
}
