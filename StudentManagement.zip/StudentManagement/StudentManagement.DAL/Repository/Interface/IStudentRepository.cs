﻿using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using System;

namespace StudentManagement.DAL.Repository.Interface
{
    public interface IStudentRepository
    {
        public Task<Student> AddNewStudent(Student user);
        public Task<Student> GetStudentDetail(Guid id);
        public Task<Student> DeleteStudent(Guid id);
        //public Task<Student> UpdateStudent(Student user);
    }
}
