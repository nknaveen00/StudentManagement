﻿using StudentManagement.DAL.Entity;

namespace StudentManagement.DAL.Repository.Interface
{
    public interface IStudentRepository
    {
        Guid CreateStudent(Student student);
        Student GetStudentById(Guid id);
        void DeleteStudent(Guid id);
        Guid UpdateStudent(Student student);
    }
}
