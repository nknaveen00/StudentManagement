﻿using StudentManagement.DAL.Entity;

namespace StudentManagement.DAL.Repository.Interface
{
    public interface IAdminRepository
    {
        Guid CreateAdmin(Admin admin);
        Admin GetAdminById(Guid id);
        void DeleteAdmin(Guid id);
        Guid UpdateAdmin(Admin admin);
    }
}
