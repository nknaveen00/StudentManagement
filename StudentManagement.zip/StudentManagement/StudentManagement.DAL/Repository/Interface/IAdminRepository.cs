﻿using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using System;

namespace StudentManagement.DAL.Repository.Interface
{
    public interface IAdminRepository
    {
        Task<Guid> AddNewAdmin(Admin admin);
        public Task<Admin> GetAdminDetail(Guid id);
        public Task<Admin> GetAdmin(Guid id);
        public Task<Admin> DeleteAdmin(Guid id);
    }
}
