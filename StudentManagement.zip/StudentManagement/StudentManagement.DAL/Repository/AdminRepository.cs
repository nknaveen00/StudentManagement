﻿using AutoMapper;
using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Repository.Interface;
using System;

namespace StudentManagement.DAL.Repository
{
    public class AdminRepository : IAdminRepository
    {
        private readonly StudentDbContext studentDb;
        //private readonly IMapper mapper;

        public AdminRepository(StudentDbContext studentDb )
        {
            this.studentDb = studentDb;
            //this.mapper = mapper;
        }

        public async Task<Guid> AddNewAdmin(Admin admin)
        {
            await studentDb.Admin.AddAsync(admin);
            await studentDb.SaveChangesAsync();
            return admin.Id;
        }

        public async Task<Admin> DeleteAdmin(Guid id)
        {
            var data = studentDb.Admin.FirstOrDefault(x => x.Id == id);
            studentDb.Admin.Remove(data);
            await studentDb.SaveChangesAsync();
            return studentDb.Admin.FirstOrDefault(x => x.Id == id);
        }

        public async  Task<Admin> GetAdmin(Guid id)
        {
            return studentDb.Admin.FirstOrDefault(x => x.Id == id);
        }

        public async Task<Admin> GetAdminDetail(Guid id)
        {
            return studentDb.Admin.FirstOrDefault(x => x.Id == id);
        }


    }
}
