﻿using StudentManagement.DAL.Entity;
using StudentManagement.DAL.Repository.Interface;

namespace StudentManagement.DAL.Repository
{
    public class AdminRepository : IAdminRepository
    {
        private readonly StudentDbContext studentDb;

        public AdminRepository(StudentDbContext studentDb )
        {
            this.studentDb = studentDb;
        }

        public void CreateAdmin(Admin admin)
        {
            studentDb.Admin.Add( admin );
        }

        public void DeleteAdmin(Guid id)
        {
            var admin=GetAdminById(id);
            studentDb.Admin.Remove( admin );
        }

        public Admin GetAdminById(Guid id)
        {
            return studentDb.Admin.Single(x=>x.Id==id);
        }

        public Guid UpdateAdmin(Admin admin)
        {
            var existAdmin = GetAdminById(admin.Id);
            existAdmin.FirstName=admin.FirstName;
            existAdmin.LastName = admin.LastName;
            existAdmin.Email = admin.Email;
            existAdmin.Password=admin.Password;
            return existAdmin.Id;
        }
    }
}
