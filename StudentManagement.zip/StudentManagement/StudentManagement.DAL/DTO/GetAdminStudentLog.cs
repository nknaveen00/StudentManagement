﻿using System;

namespace StudentManagement.DAL.DTO
{
    public class GetAdminStudentLog
    {
        public String Email { get; set; }
        public string Password { get; set; }
    }
}
