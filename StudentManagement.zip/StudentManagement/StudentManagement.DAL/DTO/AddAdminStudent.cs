﻿using System;

namespace StudentManagement.DAL.DTO
{

}
