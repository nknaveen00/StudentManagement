﻿using System;

namespace StudentManagement.DAL.DTO
{
    public class UpdateStudent
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
