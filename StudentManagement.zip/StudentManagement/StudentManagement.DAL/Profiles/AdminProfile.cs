﻿using AutoMapper;
using StudentManagement.DAL.DTO;
using StudentManagement.DAL.Entity;
using System;

namespace StudentManagement.DAL.Profiles
{
    public class AdminProfile : Profile
    {
        public AdminProfile()
        {
            CreateMap<Admin, GetAdminStudentDetail>().ReverseMap();
            CreateMap<Admin, GetAdminStudentLog>().ReverseMap(); 
            CreateMap<Admin, AddAdminStudent>().ReverseMap(); 

            CreateMap<Student, GetAdminStudentDetail>().ReverseMap();
            CreateMap<Student,GetAdminStudentLog>().ReverseMap();
            CreateMap<Student, AddAdminStudent>().ReverseMap();
            CreateMap<Student, UpdateStudent>().ReverseMap();
        }
    }
}
