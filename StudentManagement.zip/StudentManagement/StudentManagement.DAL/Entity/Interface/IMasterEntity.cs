﻿namespace StudentManagement.DAL.Entity.Interface
{
    public interface IMasterEntity
    {
        Guid Id { get; set; }
    }
}
