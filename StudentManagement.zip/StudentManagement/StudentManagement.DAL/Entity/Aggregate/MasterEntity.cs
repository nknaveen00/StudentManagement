﻿using StudentManagement.DAL.Entity.Interface;

namespace StudentManagement.DAL.Entity.Aggregate
{
    public class MasterEntity: IMasterEntity
    {
        public Guid Id { get; set; }
        public MasterEntity()
        {
            Id = Guid.NewGuid();
        }

        public MasterEntity(Guid id)
        {
            Id = id;
        }
    }
}
