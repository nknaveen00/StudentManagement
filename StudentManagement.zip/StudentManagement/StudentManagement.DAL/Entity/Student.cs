﻿using StudentManagement.DAL.Entity.Aggregate;
using System;

namespace StudentManagement.DAL.Entity
{
    public class Student : MasterEntity
    {
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public string Email { get; set; }
        //public Courses Course { get; set; }
        public string Password { get; set; }
    }
}
