﻿using StudentManagement.DAL.Entity.Aggregate;
using StudentManagement.DAL.Entity.Interface;
using System;

namespace StudentManagement.DAL.Entity
{
    public class Admin : MasterEntity, IAdmin
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        public Admin(string firstName, string lastName, string email, string password)
        {
            FirstName = firstName;
            LastName = lastName;
            Email = email;
            Password = password;
        }
    }
}
